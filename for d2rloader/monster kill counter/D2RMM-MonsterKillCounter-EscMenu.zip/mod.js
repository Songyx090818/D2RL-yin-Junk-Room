const panelName = config.panelMode === 'counterOnly'
  ? 'MonsterKillCounterOnlyPanel'
  : 'MonsterKillCounterPanel';

function addButton(path, tableName) {
  const layout = D2RMM.readJson(path);
  const table = layout.children.find(child => child.name === tableName);

  table.children.push({
    type: 'TableRowWidget',
    name: 'Row Monster Kill Counter',
    children: [
      {
        type: 'ButtonWidget',
        name: 'MonsterKillCounter',
        fields: {
          filename: 'PauseMenu\\PauseButton',
          hoveredFrame: 3,
          textString: 'MONSTER KILL COUNTER',
          pressLabelOffset: [0, 0],
          onClickMessage: 'PanelManager:TogglePanel:monster-kill-counter/' + panelName,
          textColor: '$LightButtonTextColor',
          'text/style': '$StyleFEButtonText',
          acceptsReturnKey: true,
          focusOnMouseOver: true,
          sound: 'select',
        },
      },
    ],
  });

  D2RMM.writeJson(path, layout);
}

addButton('global\\ui\\layouts\\pauselayouthd.json', 'PauseTable');
addButton('global\\ui\\layouts\\pauselayoutgardenhd.json', 'PauseTableExtra');
