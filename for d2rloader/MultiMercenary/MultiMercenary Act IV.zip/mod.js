const excelPaths = ['global\\excel', 'global\\excel\\base'];

function nextId(rows, column) {
  for (let i = rows.length - 1; i >= 0; i--) {
    if (/^\d+$/.test(rows[i][column])) return Number(rows[i][column]) + 1;
  }
}

const monsterIds = [];

for (const path of excelPaths) {
  const monsters = D2RMM.readTsv(path + '\\monstats.txt', {removeCarriageReturns: true});
  const monsterId = nextId(monsters.rows, '*hcIdx');
  monsterIds.push(monsterId);
  monsters.rows.push(
    {
      "Id": "act4hire", "*hcIdx": monsterId, "BaseId": "act4hire", "TransLvl": "0",
      "NameStr": "act4merc_class", "MonStatsEx": "act4hire", "MonType": "human", "AI": "Hireable",
      "Code": "IW", "enabled": "1", "MinGrp": "1", "MaxGrp": "1", "Velocity": "7", "Run": "11",
      "Rarity": "0", "Level": "1", "Level(N)": "34", "Level(H)": "67", "MonSound": "act3hire",
      "UMonSound": "act3hire", "threat": "11", "aidel": "1", "aidel(N)": "1", "aidel(H)": "1",
      "aidist": "16", "aidist(N)": "16", "aidist(H)": "16", "aip1": "3", "aip1(N)": "3", "aip1(H)": "3",
      "aip3": "4", "aip3(N)": "4", "aip3(H)": "4", "Align": "1", "inventory": "1", "inTown": "1",
      "opendoors": "1", "killable": "1", "switchai": "1", "leftArmItemType": "shie",
      "canNotUseTwoHandedItems": "1", "Drain": "100", "Drain(N)": "100", "Drain(H)": "100",
      "coldeffect": "-50", "coldeffect(N)": "-50", "coldeffect(H)": "-50", "DamageRegen": "4",
      "ShieldBlockOverride": "2", "*eol": "0"
    }
  );
  D2RMM.writeTsv(path + '\\monstats.txt', monsters, {addCarriageReturns: true});

  const monsters2 = D2RMM.readTsv(path + '\\monstats2.txt', {removeCarriageReturns: true});
  monsters2.rows.push(
    {
      "Id": "act4hire", "*hcIdx": monsterId, "Height": "3", "OverlayHeight": "2", "pixHeight": "96",
      "SizeX": "2", "SizeY": "2", "MeleeRng": "0", "BaseW": "1hs", "HitClass": "3", "HDv": "lit",
      "TRv": "lit,med,hvy", "LGv": "lit,med,hvy", "Rav": "lit,med,hvy", "Lav": "lit,med,hvy", "RHv": "lsd",
      "SHv": "buc", "S1v": "lit,med,hvy", "S2v": "lit,med,hvy", "HD": "1", "TR": "1", "LG": "1", "RA": "1",
      "LA": "1", "RH": "1", "SH": "1", "S1": "1", "S2": "1", "TotalPieces": "9", "mDT": "1", "mNU": "1",
      "mWL": "1", "mGH": "1", "mA1": "1", "mSC": "1", "mDD": "1", "mKB": "1", "mSQ": "1", "mRN": "1",
      "dDT": "8", "dNU": "8", "dWL": "8", "dGH": "8", "dA1": "8", "dA2": "8", "dBL": "8", "dSC": "8",
      "dS1": "8", "dS2": "8", "dS3": "8", "dS4": "8", "dDD": "8", "dKB": "8", "dSQ": "8", "dRN": "8",
      "restore": "1", "isAtt": "1", "soft": "1", "Shadow": "1", "noUniqueShift": "1", "compositeDeath": "1",
      "Light": "5", "light-r": "255", "light-g": "255", "light-b": "255", "InfernoLen": "7",
      "InfernoAnim": "11", "ResurrectMode": "NU", "*eol": "0"
    }
  );
  D2RMM.writeTsv(path + '\\monstats2.txt', monsters2, {addCarriageReturns: true});

  const hirelings = D2RMM.readTsv(path + '\\hireling.txt', {removeCarriageReturns: true});
  const hirelingId = nextId(hirelings.rows, 'Id');
  hirelings.rows.push(
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Decrepify-Normal", "Version": "100", "Id": hirelingId,
      "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "15", "Seller": "367",
      "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "1000", "Exp/Lvl": "110",
      "HP": "160", "HP/Lvl": "11", "Defense": "95", "Def/Lvl": "9",
      "Str": "49", "Str/Lvl": "10", "Dex": "40", "Dex/Lvl": "8",
      "AR": "15", "AR/Lvl": "12", "Dmg-Min": "1", "Dmg-Max": "7", "Dmg/Lvl": "4",
      "ResistFire": "35", "ResistFire/Lvl": "8", "ResistCold": "35", "ResistCold/Lvl": "8",
      "ResistLightning": "35", "ResistLightning/Lvl": "8", "ResistPoison": "35", "ResistPoison/Lvl": "8",
      "HireDesc": "skillname87", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "8",
      "LvlPerLvl1": "10",
      "Skill2": "Decrepify", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "1",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Decrepify-Normal", "Version": "100", "Id": hirelingId,
      "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "49", "Seller": "367",
      "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname87", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "18",
      "LvlPerLvl1": "10",
      "Skill2": "Decrepify", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "3",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Decrepify-Normal", "Version": "100", "Id": hirelingId,
      "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "79", "Seller": "367",
      "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname87", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "28",
      "LvlPerLvl1": "10",
      "Skill2": "Decrepify", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "5",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Decrepify-Nightmare", "Version": "100",
      "Id": hirelingId + 1, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname87", "DefaultChance": "0",
      "Skill1": "Bone Spear", "Mode1": "7", "Chance1": "65", "ChancePerLvl1": "0", "Level1": "12",
      "LvlPerLvl1": "8",
      "Skill2": "Bone Spirit", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "10",
      "LvlPerLvl2": "8",
      "Skill3": "Decrepify", "Mode3": "7", "Chance3": "20", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Decrepify-Nightmare", "Version": "100",
      "Id": hirelingId + 1, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname87", "DefaultChance": "0",
      "Skill1": "Bone Spear", "Mode1": "7", "Chance1": "65", "ChancePerLvl1": "0", "Level1": "20",
      "LvlPerLvl1": "8",
      "Skill2": "Bone Spirit", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "18",
      "LvlPerLvl2": "8",
      "Skill3": "Decrepify", "Mode3": "7", "Chance3": "20", "ChancePerLvl3": "0", "Level3": "7",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Decrepify-Hell", "Version": "100", "Id": hirelingId + 2,
      "Class": monsterId, "Act": "4", "Difficulty": "3", "Level": "79", "Seller": "367",
      "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname87", "DefaultChance": "0",
      "Skill1": "Bone Spear", "Mode1": "7", "Chance1": "65", "ChancePerLvl1": "0", "Level1": "20",
      "LvlPerLvl1": "8",
      "Skill2": "Bone Spirit", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "18",
      "LvlPerLvl2": "8",
      "Skill3": "Decrepify", "Mode3": "7", "Chance3": "20", "ChancePerLvl3": "0", "Level3": "7",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Amplify Damage-Normal", "Version": "100",
      "Id": hirelingId + 3, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "15",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "1000", "Exp/Lvl": "110",
      "HP": "160", "HP/Lvl": "11", "Defense": "95", "Def/Lvl": "9",
      "Str": "49", "Str/Lvl": "10", "Dex": "40", "Dex/Lvl": "8",
      "AR": "15", "AR/Lvl": "12", "Dmg-Min": "1", "Dmg-Max": "7", "Dmg/Lvl": "4",
      "ResistFire": "35", "ResistFire/Lvl": "8", "ResistCold": "35", "ResistCold/Lvl": "8",
      "ResistLightning": "35", "ResistLightning/Lvl": "8", "ResistPoison": "35", "ResistPoison/Lvl": "8",
      "HireDesc": "skillname66", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "8",
      "LvlPerLvl1": "10",
      "Skill2": "Amplify Damage", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "1",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Amplify Damage-Normal", "Version": "100",
      "Id": hirelingId + 3, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname66", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "18",
      "LvlPerLvl1": "10",
      "Skill2": "Amplify Damage", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "3",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Amplify Damage-Normal", "Version": "100",
      "Id": hirelingId + 3, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname66", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "28",
      "LvlPerLvl1": "10",
      "Skill2": "Amplify Damage", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "5",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Amplify Damage-Nightmare", "Version": "100",
      "Id": hirelingId + 4, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname66", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "25", "ChancePerLvl1": "0", "Level1": "20",
      "LvlPerLvl1": "12",
      "Skill2": "Bone Spear", "Mode2": "7", "Chance2": "63", "ChancePerLvl2": "0", "Level2": "12",
      "LvlPerLvl2": "8",
      "Skill3": "Amplify Damage", "Mode3": "7", "Chance3": "12", "ChancePerLvl3": "0", "Level3": "3",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Amplify Damage-Nightmare", "Version": "100",
      "Id": hirelingId + 4, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname66", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "25", "ChancePerLvl1": "0", "Level1": "32",
      "LvlPerLvl1": "12",
      "Skill2": "Bone Spear", "Mode2": "7", "Chance2": "63", "ChancePerLvl2": "0", "Level2": "20",
      "LvlPerLvl2": "8",
      "Skill3": "Amplify Damage", "Mode3": "7", "Chance3": "12", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Amplify Damage-Hell", "Version": "100",
      "Id": hirelingId + 5, "Class": monsterId, "Act": "4", "Difficulty": "3", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname66", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "25", "ChancePerLvl1": "0", "Level1": "32",
      "LvlPerLvl1": "12",
      "Skill2": "Bone Spear", "Mode2": "7", "Chance2": "63", "ChancePerLvl2": "0", "Level2": "20",
      "LvlPerLvl2": "8",
      "Skill3": "Amplify Damage", "Mode3": "7", "Chance3": "12", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Lower Resist-Normal", "Version": "100",
      "Id": hirelingId + 6, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "15",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "1000", "Exp/Lvl": "110",
      "HP": "160", "HP/Lvl": "11", "Defense": "95", "Def/Lvl": "9",
      "Str": "49", "Str/Lvl": "10", "Dex": "40", "Dex/Lvl": "8",
      "AR": "15", "AR/Lvl": "12", "Dmg-Min": "1", "Dmg-Max": "7", "Dmg/Lvl": "4",
      "ResistFire": "35", "ResistFire/Lvl": "8", "ResistCold": "35", "ResistCold/Lvl": "8",
      "ResistLightning": "35", "ResistLightning/Lvl": "8", "ResistPoison": "35", "ResistPoison/Lvl": "8",
      "HireDesc": "skillname91", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "8",
      "LvlPerLvl1": "10",
      "Skill2": "Lower Resist", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "1",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Lower Resist-Normal", "Version": "100",
      "Id": hirelingId + 6, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname91", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "18",
      "LvlPerLvl1": "10",
      "Skill2": "Lower Resist", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "3",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Lower Resist-Normal", "Version": "100",
      "Id": hirelingId + 6, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname91", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "28",
      "LvlPerLvl1": "10",
      "Skill2": "Lower Resist", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "5",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Lower Resist-Nightmare", "Version": "100",
      "Id": hirelingId + 7, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname91", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "20", "ChancePerLvl1": "0", "Level1": "18",
      "LvlPerLvl1": "10",
      "Skill2": "Bone Spear", "Mode2": "7", "Chance2": "65", "ChancePerLvl2": "0", "Level2": "12",
      "LvlPerLvl2": "8",
      "Skill3": "Lower Resist", "Mode3": "7", "Chance3": "15", "ChancePerLvl3": "0", "Level3": "3",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Lower Resist-Nightmare", "Version": "100",
      "Id": hirelingId + 7, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname91", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "20", "ChancePerLvl1": "0", "Level1": "28",
      "LvlPerLvl1": "10",
      "Skill2": "Bone Spear", "Mode2": "7", "Chance2": "65", "ChancePerLvl2": "0", "Level2": "20",
      "LvlPerLvl2": "8",
      "Skill3": "Lower Resist", "Mode3": "7", "Chance3": "15", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Lower Resist-Hell", "Version": "100",
      "Id": hirelingId + 8, "Class": monsterId, "Act": "4", "Difficulty": "3", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname91", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "20", "ChancePerLvl1": "0", "Level1": "28",
      "LvlPerLvl1": "10",
      "Skill2": "Bone Spear", "Mode2": "7", "Chance2": "65", "ChancePerLvl2": "0", "Level2": "20",
      "LvlPerLvl2": "8",
      "Skill3": "Lower Resist", "Mode3": "7", "Chance3": "15", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Life Tap-Normal", "Version": "100",
      "Id": hirelingId + 9, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "15",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "1000", "Exp/Lvl": "110",
      "HP": "160", "HP/Lvl": "11", "Defense": "95", "Def/Lvl": "9",
      "Str": "49", "Str/Lvl": "10", "Dex": "40", "Dex/Lvl": "8",
      "AR": "15", "AR/Lvl": "12", "Dmg-Min": "1", "Dmg-Max": "7", "Dmg/Lvl": "4",
      "ResistFire": "35", "ResistFire/Lvl": "8", "ResistCold": "35", "ResistCold/Lvl": "8",
      "ResistLightning": "35", "ResistLightning/Lvl": "8", "ResistPoison": "35", "ResistPoison/Lvl": "8",
      "HireDesc": "skillname82", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "8",
      "LvlPerLvl1": "10",
      "Skill2": "Life Tap", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "1",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Life Tap-Normal", "Version": "100",
      "Id": hirelingId + 9, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname82", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "18",
      "LvlPerLvl1": "10",
      "Skill2": "Life Tap", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "3",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Life Tap-Normal", "Version": "100",
      "Id": hirelingId + 9, "Class": monsterId, "Act": "4", "Difficulty": "1", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname82", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "85", "ChancePerLvl1": "0", "Level1": "28",
      "LvlPerLvl1": "10",
      "Skill2": "Life Tap", "Mode2": "7", "Chance2": "15", "ChancePerLvl2": "0", "Level2": "5",
      "LvlPerLvl2": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Life Tap-Nightmare", "Version": "100",
      "Id": hirelingId + 10, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "49",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "10000", "Exp/Lvl": "120",
      "HP": "534", "HP/Lvl": "23", "Defense": "419", "Def/Lvl": "16",
      "Str": "92", "Str/Lvl": "10", "Dex": "74", "Dex/Lvl": "8",
      "AR": "423", "AR/Lvl": "24", "Dmg-Min": "18", "Dmg-Max": "24", "Dmg/Lvl": "4",
      "ResistFire": "103", "ResistFire/Lvl": "7", "ResistCold": "103", "ResistCold/Lvl": "7",
      "ResistLightning": "103", "ResistLightning/Lvl": "7", "ResistPoison": "103", "ResistPoison/Lvl": "7",
      "HireDesc": "skillname82", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "20", "ChancePerLvl1": "0", "Level1": "16",
      "LvlPerLvl1": "10",
      "Skill2": "Bone Spirit", "Mode2": "7", "Chance2": "68", "ChancePerLvl2": "0", "Level2": "10",
      "LvlPerLvl2": "8",
      "Skill3": "Life Tap", "Mode3": "7", "Chance3": "12", "ChancePerLvl3": "0", "Level3": "3",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Life Tap-Nightmare", "Version": "100",
      "Id": hirelingId + 10, "Class": monsterId, "Act": "4", "Difficulty": "2", "Level": "79",
      "Seller": "367", "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname82", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "20", "ChancePerLvl1": "0", "Level1": "26",
      "LvlPerLvl1": "10",
      "Skill2": "Bone Spirit", "Mode2": "7", "Chance2": "68", "ChancePerLvl2": "0", "Level2": "18",
      "LvlPerLvl2": "8",
      "Skill3": "Life Tap", "Mode3": "7", "Chance3": "12", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    },
    {
      "Hireling": "Act IV Necromancer", "*SubType": "Life Tap-Hell", "Version": "100", "Id": hirelingId + 11,
      "Class": monsterId, "Act": "4", "Difficulty": "3", "Level": "79", "Seller": "367",
      "NameFirst": "act4merc01", "NameLast": "act4merc10",
      "Gold": "21000", "Exp/Lvl": "130",
      "HP": "1224", "HP/Lvl": "34", "Defense": "907", "Def/Lvl": "25",
      "Str": "130", "Str/Lvl": "10", "Dex": "104", "Dex/Lvl": "8",
      "AR": "1143", "AR/Lvl": "36", "Dmg-Min": "33", "Dmg-Max": "39", "Dmg/Lvl": "4",
      "ResistFire": "155", "ResistFire/Lvl": "5", "ResistCold": "155", "ResistCold/Lvl": "5",
      "ResistLightning": "155", "ResistLightning/Lvl": "5", "ResistPoison": "155", "ResistPoison/Lvl": "5",
      "HireDesc": "skillname82", "DefaultChance": "0",
      "Skill1": "Teeth", "Mode1": "7", "Chance1": "20", "ChancePerLvl1": "0", "Level1": "26",
      "LvlPerLvl1": "10",
      "Skill2": "Bone Spirit", "Mode2": "7", "Chance2": "68", "ChancePerLvl2": "0", "Level2": "18",
      "LvlPerLvl2": "8",
      "Skill3": "Life Tap", "Mode3": "7", "Chance3": "12", "ChancePerLvl3": "0", "Level3": "5",
      "LvlPerLvl3": "2",
      "HiringMaxLevelDifference": "1", "resurrectcostmultiplier": "15", "resurrectcostdivisor": "2",
      "resurrectcostmax": "50000", "equivalentcharclass": "nec"
    }
  );
  D2RMM.writeTsv(path + '\\hireling.txt', hirelings, {addCarriageReturns: true});

  if (config.useHireableSprites) {
    const descriptions = D2RMM.readTsv(path + '\\skilldesc.txt', {removeCarriageReturns: true});
    const hireableIcons = {
      teeth: '29', 'bone spear': '30', decrepify: '31', 'lower resist': '32',
      'bone spirit': '33', 'amplify damage': '34', 'life tap': '35'
    };
    for (const row of descriptions.rows) {
      if (row.skilldesc in hireableIcons) row.HireableIconCel = hireableIcons[row.skilldesc];
    }
    D2RMM.writeTsv(path + '\\skilldesc.txt', descriptions, {addCarriageReturns: true});
  }
}

const names = [
  {
    "Key": "act4merc01", "enUS": "Amon", "zhTW": "阿蒙", "deDE": "Amon",
    "esES": "Amon", "frFR": "Amon", "itIT": "Amon", "koKR": "아몬",
    "plPL": "Amon", "esMX": "Amon", "jaJP": "アモン", "ptBR": "Amon",
    "ruRU": "Амон", "zhCN": "阿蒙"
  },
  {
    "Key": "act4merc02", "enUS": "Kalan", "zhTW": "卡蘭", "deDE": "Kalan",
    "esES": "Kalan", "frFR": "Kalan", "itIT": "Kalan", "koKR": "칼란",
    "plPL": "Kalan", "esMX": "Kalan", "jaJP": "カラン", "ptBR": "Kalan",
    "ruRU": "Калан", "zhCN": "卡兰"
  },
  {
    "Key": "act4merc03", "enUS": "Nereth", "zhTW": "內瑞斯", "deDE": "Nereth",
    "esES": "Nereth", "frFR": "Nereth", "itIT": "Nereth", "koKR": "네레스",
    "plPL": "Nereth", "esMX": "Nereth", "jaJP": "ネレス", "ptBR": "Nereth",
    "ruRU": "Нерет", "zhCN": "内瑞斯"
  },
  {
    "Key": "act4merc04", "enUS": "Orlan", "zhTW": "奧蘭", "deDE": "Orlan",
    "esES": "Orlan", "frFR": "Orlan", "itIT": "Orlan", "koKR": "오를란",
    "plPL": "Orlan", "esMX": "Orlan", "jaJP": "オルラン", "ptBR": "Orlan",
    "ruRU": "Орлан", "zhCN": "奥兰"
  },
  {
    "Key": "act4merc05", "enUS": "Sethis", "zhTW": "賽西斯", "deDE": "Sethis",
    "esES": "Sethis", "frFR": "Sethis", "itIT": "Sethis", "koKR": "세티스",
    "plPL": "Sethis", "esMX": "Sethis", "jaJP": "セティス", "ptBR": "Sethis",
    "ruRU": "Сетис", "zhCN": "赛西斯"
  },
  {
    "Key": "act4merc06", "enUS": "Varek", "zhTW": "瓦雷克", "deDE": "Varek",
    "esES": "Varek", "frFR": "Varek", "itIT": "Varek", "koKR": "바레크",
    "plPL": "Varek", "esMX": "Varek", "jaJP": "ヴァレク", "ptBR": "Varek",
    "ruRU": "Варек", "zhCN": "瓦雷克"
  },
  {
    "Key": "act4merc07", "enUS": "Zareth", "zhTW": "札瑞斯", "deDE": "Zareth",
    "esES": "Zareth", "frFR": "Zareth", "itIT": "Zareth", "koKR": "자레스",
    "plPL": "Zareth", "esMX": "Zareth", "jaJP": "ザレス", "ptBR": "Zareth",
    "ruRU": "Зарет", "zhCN": "札瑞斯"
  },
  {
    "Key": "act4merc08", "enUS": "Morthan", "zhTW": "莫爾坦", "deDE": "Morthan",
    "esES": "Morthan", "frFR": "Morthan", "itIT": "Morthan", "koKR": "모르탄",
    "plPL": "Morthan", "esMX": "Morthan", "jaJP": "モルタン", "ptBR": "Morthan",
    "ruRU": "Мортан", "zhCN": "莫尔坦"
  },
  {
    "Key": "act4merc09", "enUS": "Isran", "zhTW": "伊斯朗", "deDE": "Isran",
    "esES": "Isran", "frFR": "Isran", "itIT": "Isran", "koKR": "이스란",
    "plPL": "Isran", "esMX": "Isran", "jaJP": "イスラン", "ptBR": "Isran",
    "ruRU": "Исран", "zhCN": "伊斯朗"
  },
  {
    "Key": "act4merc10", "enUS": "Theron", "zhTW": "瑟隆", "deDE": "Theron",
    "esES": "Theron", "frFR": "Theron", "itIT": "Theron", "koKR": "테론",
    "plPL": "Theron", "esMX": "Theron", "jaJP": "セロン", "ptBR": "Theron",
    "ruRU": "Терон", "zhCN": "瑟隆"
  }
];
const mercenaryStrings = D2RMM.readJson('local\\lng\\strings\\mercenaries.json');
for (const name of names) {
  mercenaryStrings.push({id: D2RMM.getNextStringID(), ...name});
}
D2RMM.writeJson('local\\lng\\strings\\mercenaries.json', mercenaryStrings);

const monsterStrings = D2RMM.readJson('local\\lng\\strings\\monsters.json');
monsterStrings.push({
  id: D2RMM.getNextStringID(),
  Key: 'act4merc_class',
  enUS: "Necromancer Mercenary",
  zhTW: "死靈法師傭兵",
  deDE: "Totenbeschwörer-Söldner",
  esES: "Mercenario nigromante",
  frFR: "Mercenaire nécromancien",
  itIT: "Mercenario negromante",
  koKR: "강령술사 용병",
  plPL: "Najemnik nekromanta",
  esMX: "Mercenario nigromante",
  jaJP: "ネクロマンサーの傭兵",
  ptBR: "Mercenário necromante",
  ruRU: "Наемник-некромант",
  zhCN: "死灵法师佣兵"
});
D2RMM.writeJson('local\\lng\\strings\\monsters.json', monsterStrings);
const models = D2RMM.readJson('hd\\character\\monsters.json');
models.act4hire = 'act4hire';
D2RMM.writeJson('hd\\character\\monsters.json', models);

const inventory = D2RMM.readJson('global\\ui\\layouts\\hirelinginventorypanelhd.json');
inventory.fields.slotBackgroundOverrides.push({
  monsterClass: monsterIds[0], rightBackgroundFrame: 2, leftBackgroundFrame: 3
});
D2RMM.writeJson('global\\ui\\layouts\\hirelinginventorypanelhd.json', inventory);

D2RMM.copyFile("file\\hd\\character\\enemy\\act4hire.json", "hd\\character\\enemy\\act4hire.json", true);
D2RMM.copyFile("file\\hd\\character\\enemy\\act4hire\\act4hire_flail_state_machine.json", "hd\\character\\enemy\\act4hire\\act4hire_flail_state_machine.json", true);
D2RMM.copyFile("file\\hd\\character\\enemy\\act4hire\\act4hire_state_machine.json", "hd\\character\\enemy\\act4hire\\act4hire_state_machine.json", true);

if (config.useHireableSprites) {
  D2RMM.copyFile('file\\hd\\global\\ui\\spells\\hireables', 'hd\\global\\ui\\spells\\hireables', true);
}
